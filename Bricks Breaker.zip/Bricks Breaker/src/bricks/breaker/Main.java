/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package bricks.breaker;

import javax.swing.JFrame;

/**
 *
 * @author Asus
 */
public class Main {

    /**
     * @param args thMaie command line arguments
     */
    public static void main(String[] args) {
        JFrame obj = new JFrame ();
        GamePlay gameplay = new GamePlay();
        obj.setBounds(10,10,700, 600);
        obj.setTitle("Breakout Ball");
        obj.setResizable(false);
        obj.setVisible(true);
        obj.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        obj.add(gameplay);
    }
    
}
